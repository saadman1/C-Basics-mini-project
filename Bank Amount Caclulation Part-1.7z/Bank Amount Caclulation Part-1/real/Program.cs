﻿using System;
using System.Diagnostics;
using System.Dynamic;

namespace real
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal principal;
            decimal interest;
            decimal monthlyPayment;
           while(true) {
                principal = positivedecimal("please Enter the principal : ");
                interest = positivedecimal("please Enter the interest rate : ");
                monthlyPayment = positivedecimal("please Enter the monthlypay : ");
                if (principal * interest / 1200 < monthlyPayment)
                    break;
                    Console.WriteLine("The monthly payment does not cover the interest");
               
            }
            decimal totalInterest = TotalInterest(principal, interest, monthlyPayment);

            static decimal positivedecimal(string prompt)
            {
                decimal result;
                while (true)
                {
                    Console.WriteLine(prompt);
                    string principalText = Console.ReadLine();
                    bool success = decimal.TryParse(principalText, out result);
                    if (!success)

                        Console.WriteLine("Please Enter a decimal value.");
                    else if (result < 0.0m)
                        Console.WriteLine("Please Enter a positive decimal value.");
                    else
                        return result;

                }

            }
            static decimal TotalInterest(decimal principal, decimal interest, decimal monthlyPayment)
            {
                if (principal < 0.0m)
                    throw new ArgumentException("Principal must be positive", "Principal");
                if(interest< 0.0m)
                throw new ArgumentException("interest must be positive", "interest");
                if(monthlyPayment<0.0m)
                throw new ArgumentException("monthlyPayment must be positive", "monthlyPayment");
                if (principal * interest / 1200 >= monthlyPayment)
                    throw new ArgumentException("monthly payment does not cover interest", "monthlyPayment");

                decimal totalInterest = 0.0m;
                decimal currentPrincipal = principal;
                while (0.0m < currentPrincipal)
                {
                    decimal currentInterest = currentPrincipal * interest / 1200;
                    decimal reduction = monthlyPayment - currentInterest;
                    Debug.Assert(reduction > 0.0m);
                    currentPrincipal = currentPrincipal - reduction;
                    totalInterest = totalInterest + currentInterest;
                }
                return totalInterest;

            }
        }
    }
}
